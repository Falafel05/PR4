﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr4
{
    class Program
    {
        static void Main(string[] args)
        {
            CreditAccount test = new CreditAccount();
            test.delCredit();
            test.getFullInfo();
            
            Account testi = new Account();
            testi.deposit(1000);
            testi.getFullInfo();
            
            Organization organization = new Organization();
            organization.setTitle("");
            organization.GETFULL();
            Console.ReadKey();
        }
    }
}
